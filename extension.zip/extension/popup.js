/**
 * AI Safety Tool - Popup v2.0 with Google Sign-In
 */

import { signInWithGoogle, signOut, getCurrentUser, getUserId } from './auth.js';

const BACKEND = "https://ai-safety-tool.onrender.com";

// ─── State ────────────────────────────────────────────────────────────────────
let currentData = null;
let refreshInterval = null;
let isSettingsOpen = false;

// ─── DOM References ───────────────────────────────────────────────────────────
const els = {
  statusDot: document.getElementById("statusDot"),
  statusLabel: document.getElementById("statusLabel"),
  riskCard: document.getElementById("riskCard"),
  riskBadge: document.getElementById("riskBadge"),
  gaugeFill: document.getElementById("gaugeFill"),
  gaugeScore: document.getElementById("gaugeScore"),
  riskMessage: document.getElementById("riskMessage"),
  statCopies: document.getElementById("statCopies"),
  statTime: document.getElementById("statTime"),
  statStreak: document.getElementById("statStreak"),
  siteCard: document.getElementById("siteCard"),
  siteName: document.getElementById("siteName"),
  flagsSection: document.getElementById("flagsSection"),
  flagsList: document.getElementById("flagsList"),
  mainPanel: document.getElementById("mainPanel"),
  settingsPanel: document.getElementById("settingsPanel"),
  dashboardBtn: document.getElementById("dashboardBtn"),
  refreshBtn: document.getElementById("refreshBtn"),
  settingsBtn: document.getElementById("settingsBtn"),
  backBtn: document.getElementById("backBtn"),
  saveSettingsBtn: document.getElementById("saveSettingsBtn"),
  resetBtn: document.getElementById("resetBtn"),
  toggleTracking: document.getElementById("toggleTracking"),
  toggleWarnings: document.getElementById("toggleWarnings"),
  sensitivitySelect: document.getElementById("sensitivitySelect"),
  dailyGoalInput: document.getElementById("dailyGoalInput")
};

// ─── Risk Gauge ───────────────────────────────────────────────────────────────
function updateGauge(score, level) {
  const arcLength = 157;
  const offset = arcLength - (arcLength * Math.min(score, 100) / 100);
  els.gaugeFill.style.strokeDashoffset = offset;
  els.gaugeFill.className = "gauge-fill";
  els.riskCard.className = "risk-card";
  els.riskBadge.className = "risk-badge";
  if (level === "moderate") {
    els.gaugeFill.classList.add("moderate");
    els.riskCard.classList.add("moderate");
    els.riskBadge.classList.add("moderate");
  } else if (level === "high") {
    els.gaugeFill.classList.add("high");
    els.riskCard.classList.add("high");
    els.riskBadge.classList.add("high");
  } else if (level === "critical") {
    els.gaugeFill.classList.add("critical");
    els.riskCard.classList.add("critical");
    els.riskBadge.classList.add("critical");
  }
  els.gaugeScore.textContent = score;
  els.riskBadge.textContent = level.toUpperCase();
}

function setStatus(state, label) {
  els.statusDot.className = "status-dot " + (state || "");
  els.statusLabel.textContent = label;
}

function formatTime(minutes) {
  if (minutes < 60) return `${minutes}m`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function animateValue(el, from, to, duration = 600) {
  if (from === to) return;
  const start = performance.now();
  const range = to - from;
  function step(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(from + range * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function renderFlags(events) {
  const allFlags = [];
  events.forEach(event => {
    if (event.flags && event.flags.length) {
      event.flags.forEach(flag => {
        allFlags.push({
          label: typeof flag === "string" ? flag : flag.label,
          time: new Date(event.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          category: event.category || "general"
        });
      });
    }
  });
  if (allFlags.length === 0) {
    els.flagsSection.style.display = "none";
    return;
  }
  els.flagsSection.style.display = "flex";
  const categoryIcons = { homework: "📚", writing: "✍️", coding: "💻", research: "🔬", creative: "🎨", general: "⚠️" };
  const html = allFlags.slice(0, 3).map(f => `
    <div class="flag-item">
      <span class="flag-icon">${categoryIcons[f.category] || "⚠️"}</span>
      <span class="flag-text">${f.label}</span>
      <span class="flag-time">${f.time}</span>
    </div>
  `).join("");
  els.flagsList.innerHTML = html;
}

function renderData(data) {
  const prev = currentData;
  currentData = data;
  const risk = data.currentRisk || {};
  const score = risk.score || 0;
  const level = risk.level || "low";
  updateGauge(score, level);
  els.riskMessage.textContent = risk.message || "Your AI usage looks healthy.";
  const prevCopies = prev?.copyCount || 0;
  const copies = data.copyCount || 0;
  if (copies !== prevCopies) animateValue(els.statCopies, prevCopies, copies);
  else els.statCopies.textContent = copies;
  els.statTime.textContent = formatTime(data.totalTimeMinutes || 0);
  els.statStreak.textContent = data.streak || 0;
  if (score >= 60) setStatus("danger", `Risk: ${level}`);
  else if (score >= 30) setStatus("warning", `Risk: ${level}`);
  else setStatus("", "Monitoring active");
  const recentEvents = data.recentEvents || [];
  renderFlags(recentEvents);
  chrome.runtime.sendMessage({ type: "GET_STATE" }, (state) => {
    if (state && state.activeAISite) {
      els.siteCard.style.display = "flex";
      els.siteName.textContent = `Monitoring ${state.activeAISite}`;
    } else {
      els.siteCard.style.display = "none";
    }
  });
}

async function loadStats() {
  const userId = await getUserId();
  try {
    const res = await fetch(`${BACKEND}/stats/summary?userId=${userId}`, { signal: AbortSignal.timeout(5000) });
    if (!res.ok) throw new Error("Backend error");
    const data = await res.json();
    renderData(data);
  } catch (err) {
    chrome.storage.local.get(["totalCopies", "riskLevel", "riskScore", "sessionTime"], (stored) => {
      const fallback = {
        copyCount: stored.totalCopies || 0,
        totalTimeMinutes: Math.floor((stored.sessionTime || 0) / 60),
        streak: 0,
        currentRisk: {
          score: stored.riskScore || 0,
          level: stored.riskLevel || "low",
          message: stored.riskLevel === "high" ? "High AI dependency detected." : "Tracking from local cache."
        },
        recentEvents: []
      };
      renderData(fallback);
      setStatus("inactive", "Backend offline — local data");
    });
  }
}

function loadSettings() {
  chrome.storage.local.get(["settings"], (data) => {
    const s = data.settings || {};
    els.toggleTracking.checked = s.trackingEnabled !== false;
    els.toggleWarnings.checked = s.warningsEnabled !== false;
    els.sensitivitySelect.value = s.sensitivityLevel || "medium";
    els.dailyGoalInput.value = s.dailyGoal || 30;
  });
}

function saveSettings() {
  const settings = {
    trackingEnabled: els.toggleTracking.checked,
    warningsEnabled: els.toggleWarnings.checked,
    sensitivityLevel: els.sensitivitySelect.value,
    dailyGoal: parseInt(els.dailyGoalInput.value) || 30
  };
  chrome.storage.local.set({ settings });
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, { type: "UPDATE_SETTINGS", settings }).catch(() => {});
    });
  });
  els.saveSettingsBtn.textContent = "✓ Saved!";
  setTimeout(() => {
    els.saveSettingsBtn.textContent = "Save Settings";
    showMain();
  }, 1200);
}

function showSettings() {
  els.mainPanel.style.display = "none";
  els.settingsPanel.style.display = "flex";
  loadSettings();
  isSettingsOpen = true;
}

function showMain() {
  els.settingsPanel.style.display = "none";
  els.mainPanel.style.display = "flex";
  isSettingsOpen = false;
}

async function updateUserUI() {
  const user = await getCurrentUser();
  if (user) {
    document.getElementById('userAvatar').src = user.picture;
    document.getElementById('userName').textContent = user.name;
    document.getElementById('signInBtn').style.display = 'none';
    document.getElementById('userInfo').style.display = 'flex';
  } else {
    document.getElementById('signInBtn').style.display = 'block';
    document.getElementById('userInfo').style.display = 'none';
  }
}

// ─── Event Listeners ──────────────────────────────────────────────────────────
els.dashboardBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/index.html") });
  window.close();
});
els.refreshBtn.addEventListener("click", () => {
  els.refreshBtn.style.opacity = "0.5";
  loadStats().finally(() => { els.refreshBtn.style.opacity = "1"; });
});
els.settingsBtn.addEventListener("click", showSettings);
els.backBtn.addEventListener("click", showMain);
els.saveSettingsBtn.addEventListener("click", saveSettings);
els.resetBtn.addEventListener("click", () => {
  if (!confirm("Reset all tracking data? This cannot be undone.")) return;
  chrome.runtime.sendMessage({ type: "RESET" }, () => {
    chrome.storage.local.clear();
    loadStats();
    showMain();
  });
});

document.getElementById('signInBtn')?.addEventListener('click', async () => {
  await signInWithGoogle();
  updateUserUI();
  loadStats();
});
document.getElementById('signOutBtn')?.addEventListener('click', async () => {
  await signOut();
  updateUserUI();
  loadStats();
});

// ─── Init ─────────────────────────────────────────────────────────────────────
updateUserUI();
loadStats();
refreshInterval = setInterval(() => { if (!isSettingsOpen) loadStats(); }, 5000);
window.addEventListener("unload", () => { if (refreshInterval) clearInterval(refreshInterval); });