const BACKEND = "https://ai-safety-tool.onrender.com";

async function loadHistory() {
  const container = document.getElementById("history");
  if(!container) return;
  
  try {
    const res = await fetch(`${BACKEND}/stats/events?userId=default&limit=30`);
    if(!res.ok) throw new Error();
    const data = await res.json();
    const events = data.events || [];
    if(events.length===0) throw new Error();
    
    container.innerHTML = events.map(e=>`
      <div class="card" style="margin-bottom:12px">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px">
          <span style="font-weight:600">${e.ai||"Unknown AI"}</span>
          <span style="color:var(--text-3);font-size:11px">${new Date(e.timestamp).toLocaleString()}</span>
        </div>
        <div style="font-size:12px;color:var(--text-2);margin-bottom:6px">${(e.text||"").substring(0,150)}${(e.text||"").length>150?"…":""}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          ${(e.flags||[]).slice(0,3).map(f=>`<span style="background:rgba(239,68,68,0.1);color:#ef4444;padding:2px 6px;border-radius:4px;font-size:10px">${typeof f==="string"?f:f.label}</span>`).join("")}
          <span style="background:rgba(56,189,248,0.1);color:#38bdf8;padding:2px 6px;border-radius:4px;font-size:10px">Risk: ${e.riskScore||0}</span>
        </div>
      </div>
    `).join("");
  } catch(err) {
    chrome.storage.local.get(["copyEvents"], (data) => {
      const events = data.copyEvents || [];
      if(events.length===0) {
        container.innerHTML = `<div class="card" style="padding:40px;text-align:center">No activity yet. Copy something on an AI site.</div>`;
        return;
      }
      container.innerHTML = events.slice(0,30).map(e=>`
        <div class="card" style="margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span style="font-weight:600">${e.ai||"Unknown"}</span>
            <span style="color:var(--text-3);font-size:11px">${new Date(e.timestamp).toLocaleString()}</span>
          </div>
          <div style="font-size:12px;color:var(--text-2);margin-bottom:6px">${(e.text||"").substring(0,150)}</div>
          <div style="display:flex;gap:6px">${(e.flags||[]).slice(0,2).map(f=>`<span style="background:rgba(239,68,68,0.1);color:#ef4444;padding:2px 6px;border-radius:4px;font-size:10px">${typeof f==="string"?f:f.label}</span>`).join("")}</div>
        </div>
      `).join("");
    });
  }
}

loadHistory();
setInterval(loadHistory, 5000);