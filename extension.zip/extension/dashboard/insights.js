// extension/dashboard/insights.js
const BACKEND = "https://ai-safety-tool.onrender.com";

const TYPE_COLORS = {
  warning: { bg: "rgba(245,158,11,0.08)", border: "rgba(245,158,11,0.2)", accent: "#f59e0b" },
  danger: { bg: "rgba(239,68,68,0.08)", border: "rgba(239,68,68,0.2)", accent: "#ef4444" },
  success: { bg: "rgba(34,197,94,0.08)", border: "rgba(34,197,94,0.2)", accent: "#22c55e" },
  info: { bg: "rgba(56,189,248,0.08)", border: "rgba(56,189,248,0.2)", accent: "#38bdf8" },
  tip: { bg: "rgba(129,140,248,0.08)", border: "rgba(129,140,248,0.2)", accent: "#818cf8" },
  pattern: { bg: "rgba(255,255,255,0.04)", border: "rgba(255,255,255,0.08)", accent: "#94a3b8" }
};

async function loadInsights() {
  try {
    const res = await fetch(`${BACKEND}/insights?userId=default`);
    const data = await res.json();

    const feed = document.getElementById("insightsFeed");
    const recs = document.getElementById("recommendationsList");

    if (data.insights && data.insights.length > 0) {
      feed.innerHTML = data.insights.map(ins => {
        const theme = TYPE_COLORS[ins.type] || TYPE_COLORS.info;
        return `
          <div class="card" style="background:${theme.bg};border-color:${theme.border};transition:0.3s">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <span style="font-size:22px">${ins.icon}</span>
              <div style="font-size:14px;font-weight:700;color:${theme.accent}">${ins.title}</div>
            </div>
            <p style="font-size:12.5px;color:var(--text-2);line-height:1.6">${ins.body}</p>
          </div>
        `;
      }).join("");
    } else {
      feed.innerHTML = `
        <div class="card" style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-3)">
          <div style="font-size:28px;margin-bottom:12px">🌱</div>
          <div style="font-size:13px">Keep using AI tools — insights will appear here as data builds up.</div>
        </div>
      `;
    }

    if (data.recommendations && data.recommendations.length > 0) {
      const priorityColors = { high: "#ef4444", medium: "#f59e0b", low: "#22c55e" };
      recs.innerHTML = data.recommendations.map(r => `
        <div style="display:flex;align-items:flex-start;gap:12px;padding:14px;background:var(--bg-3);border:1px solid var(--border);border-radius:12px">
          <span style="font-size:22px;flex-shrink:0">${r.icon}</span>
          <div style="flex:1">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
              <span style="font-size:13px;font-weight:700">${r.title}</span>
              <span style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.6px;padding:2px 7px;border-radius:20px;background:${priorityColors[r.priority]}20;color:${priorityColors[r.priority]}">${r.priority}</span>
            </div>
            <p style="font-size:12px;color:var(--text-2);line-height:1.6">${r.body}</p>
          </div>
        </div>
      `).join("");
    } else {
      recs.innerHTML = `<div style="color:var(--text-3);font-size:12px;padding:16px 0">No recommendations yet.</div>`;
    }

  } catch (err) {
    document.getElementById("insightsFeed").innerHTML = `
      <div class="card" style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-3)">
        <div style="font-size:28px;margin-bottom:12px">📡</div>
        <div>Backend offline. Start the server to see insights.</div>
      </div>
    `;
  }
}

loadInsights();