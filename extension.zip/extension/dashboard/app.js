const BACKEND = "https://ai-safety-tool.onrender.com";

const PLATFORM_EMOJIS = { ChatGPT: "🤖", Claude: "💜", Gemini: "✨", Perplexity: "🔍", Copilot: "🪟", Other: "🌐" };
const CATEGORY_EMOJIS = { homework: "📚", writing: "✍️", coding: "💻", research: "🔬", creative: "🎨", general: "📝" };

function formatTime(minutes) { return minutes < 60 ? `${minutes}m` : `${Math.floor(minutes/60)}h ${minutes%60}m`; }
function timeAgo(ts) { const m = Math.floor((Date.now() - ts)/60000); if (m<1) return "just now"; if (m<60) return `${m}m ago`; return `${Math.floor(m/60)}h ago`; }
function animateValue(el, from, to, dur=700, suffix="") { if (!el || from===to) { if(el) el.textContent = to+suffix; return; } const start = performance.now(); function step(now) { const t = Math.min((now-start)/dur,1); const eased = 1 - Math.pow(1-t,3); el.textContent = Math.round(from + (to-from)*eased) + suffix; if (t<1) requestAnimationFrame(step); } requestAnimationFrame(step); }

document.getElementById("currentDate").textContent = new Date().toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" });

async function getUserId() {
  return new Promise((resolve) => {
    chrome.storage.local.get("user", (result) => {
      resolve(result.user ? result.user.email : "default");
    });
  });
}

function renderBehaviorScore(bs) { if(!bs) return; const score = bs.score || 0; const circ = 213.6; const offset = circ - (circ * score/100); const ring = document.getElementById("behaviorRing"); if(ring) { ring.style.strokeDashoffset = offset; ring.style.stroke = score>=80?"#22c55e":score>=60?"#f59e0b":"#ef4444"; } animateValue(document.getElementById("behaviorScore"), 0, score); const gradeEl = document.getElementById("behaviorGrade"); if(gradeEl) { gradeEl.textContent = bs.grade || "—"; gradeEl.style.color = score>=80?"#22c55e":score>=60?"#f59e0b":"#ef4444"; } const labelEl = document.getElementById("behaviorLabel"); if(labelEl) labelEl.textContent = bs.label || "—"; }

function renderRisk(risk) { if(!risk) return; const { score=0, level="low", emoji="✅", message="", triggers=[] } = risk; const card = document.getElementById("riskHeroCard"); if(card) card.className = "hero-card risk-hero-card " + level; const emojiEl = document.getElementById("riskEmoji"); if(emojiEl) emojiEl.textContent = emoji; const levelEl = document.getElementById("riskLevelText"); if(levelEl) levelEl.textContent = level.charAt(0).toUpperCase() + level.slice(1); animateValue(document.getElementById("riskScore"), 0, score); const msgEl = document.getElementById("riskMsg"); if(msgEl) msgEl.textContent = message; const barEl = document.getElementById("riskBarFill"); if(barEl) { barEl.style.width = score+"%"; barEl.className = "risk-bar-fill "+level; } const triggersEl = document.getElementById("riskTriggers"); if(triggersEl && triggers.length) triggersEl.innerHTML = triggers.slice(0,4).map(t => `<span class="risk-trigger-tag">${t}</span>`).join(""); }

function renderStats(data) { animateValue(document.getElementById("tileCopiesVal"), 0, data.copyCount || 0); document.getElementById("tileTimeVal").textContent = formatTime(data.totalTimeMinutes || 0); animateValue(document.getElementById("tileStreakVal"), 0, data.streak || 0); animateValue(document.getElementById("tilePointsVal"), 0, data.points || 0); const streakSub = document.getElementById("tileStreakSub"); if(streakSub) streakSub.textContent = data.longestStreak ? `Best: ${data.longestStreak} days` : "Keep going!"; }

function renderWeeklyChart(dailyStats) {
  const canvas = document.getElementById("weeklyChart");
  if(!canvas || !dailyStats || !dailyStats.length) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.parentElement.clientWidth, H = 160;
  canvas.width = W; canvas.height = H;
  ctx.clearRect(0,0,W,H);
  const labels = dailyStats.map(d=>d.label);
  const copies = dailyStats.map(d=>d.copies);
  const times = dailyStats.map(d=>d.timeMinutes);
  const maxCopies = Math.max(...copies,1);
  const maxTime = Math.max(...times,1);
  const padL=8, padR=8, padT=10, padB=28;
  const chartW = W-padL-padR, chartH = H-padT-padB;
  const barGroupW = chartW / labels.length;
  const barW = Math.min(barGroupW*0.3, 18);
  const gap = 4;
  for(let i=0;i<=4;i++) { let y=padT+(chartH/4)*i; ctx.beginPath(); ctx.moveTo(padL,y); ctx.lineTo(W-padR,y); ctx.strokeStyle="rgba(255,255,255,0.04)"; ctx.stroke(); }
  labels.forEach((label,i)=>{
    const x = padL + i*barGroupW + barGroupW/2;
    const copyH = (copies[i]/maxCopies)*chartH;
    const copyX = x - barW - gap/2;
    const copyY = padT+chartH-copyH;
    ctx.fillStyle = "rgba(56,189,248,0.8)";
    ctx.fillRect(copyX, copyY, barW, Math.max(copyH,2));
    const timeH = (times[i]/maxTime)*chartH;
    const timeX = x + gap/2;
    const timeY = padT+chartH-timeH;
    ctx.fillStyle = "rgba(129,140,248,0.8)";
    ctx.fillRect(timeX, timeY, barW, Math.max(timeH,2));
    if(copies[i]>0) { ctx.fillStyle = "#38bdf8"; ctx.font="bold 9px 'Plus Jakarta Sans'"; ctx.fillText(copies[i], copyX+barW/2, copyY-4); }
    ctx.fillStyle = "rgba(148,163,184,0.7)";
    ctx.font="500 10px 'Plus Jakarta Sans'";
    ctx.fillText(label.split(",")[0], x, H-6);
  });
}

function renderPlatforms(platforms) { const el = document.getElementById("platformList"); if(!el) return; if(!platforms || platforms.length===0) { el.innerHTML='<div class="empty-state"><div>🌐</div><div>No platform data</div></div>'; return; } el.innerHTML = platforms.map(p=>`<div class="platform-item"><div class="platform-header"><span class="platform-name"><span class="platform-emoji">${PLATFORM_EMOJIS[p.platform]||"🤖"}</span>${p.platform}</span><span class="platform-count">${p.count} copies · ${p.percentage}%</span></div><div class="platform-bar-track"><div class="platform-bar-fill" style="width:${p.percentage}%"></div></div></div>`).join(""); }

function renderCategories(categories) { const el = document.getElementById("categoryList"); if(!el) return; const entries = Object.entries(categories||{}).filter(([,v])=>v>0).sort(([,a],[,b])=>b-a); if(entries.length===0) { el.innerHTML='<div class="empty-state"><div>📊</div><div>No data yet</div></div>'; return; } const total = entries.reduce((s,[,v])=>s+v,0); el.innerHTML = entries.map(([cat,count])=>`<div class="category-item"><span class="category-emoji">${CATEGORY_EMOJIS[cat]||"📝"}</span><div class="category-info"><div class="category-name">${cat}</div><div class="category-count">${count} events</div></div><div class="category-bar-track"><div class="category-bar-fill" style="width:${Math.round(count/total*100)}%"></div></div></div>`).join(""); }

function renderAchievements(earned) { const el = document.getElementById("achievementsList"); const countEl = document.getElementById("achieveCount"); const allAchievements = [ { id:"first_copy", title:"First Copy", desc:"Tracked first AI copy", icon:"📋" }, { id:"streak_3", title:"3-Day Streak", desc:"Used AI mindfully for 3 days", icon:"🔥" }, { id:"streak_7", title:"Weekly Warrior", desc:"7-day streak", icon:"⚡" }, { id:"copy_10", title:"Copy Watcher", desc:"10 copy events", icon:"👀" }, { id:"multi_ai", title:"AI Explorer", desc:"Used 3+ AI tools", icon:"🌐" } ]; const earnedIds = new Set((earned||[]).map(a=>a.id)); if(countEl) countEl.textContent = earnedIds.size; if(!el) return; el.innerHTML = allAchievements.map(a=>`<div class="achievement-item ${earnedIds.has(a.id)?"":"achievement-locked"}"><span class="achievement-icon">${a.icon}</span><div class="achievement-info"><div class="achievement-title">${a.title}</div><div class="achievement-desc">${a.desc}</div></div>${earnedIds.has(a.id)?"✅":""}</div>`).join(""); }

function renderActivity(events) { const el = document.getElementById("activityList"); if(!el) return; if(!events || events.length===0) { el.innerHTML='<div class="empty-state"><div>📭</div><div>No activity yet.<br>Visit an AI site to start tracking.</div></div>'; return; } el.innerHTML = events.map(e=>{ const risk = e.riskScore>=60?"high":e.riskScore>=30?"moderate":"low"; const preview = (e.text||"").substring(0,60)+(e.text?.length>60?"…":""); return `<div class="activity-item"><div class="activity-dot ${risk}"></div><div class="activity-content"><div class="activity-text">${preview||"Copy event"}</div><div class="activity-meta"><span class="activity-badge ${e.category||"general"}">${e.category||"general"}</span><span class="activity-badge" style="background:rgba(129,140,248,0.1);color:#818cf8">${e.ai||"Unknown"}</span><span class="activity-time">${timeAgo(e.timestamp)}</span></div>${e.flags?.length?`<div class="activity-flags">${e.flags.slice(0,2).map(f=>`<span class="activity-flag">${typeof f==="string"?f:f.label}</span>`).join("")}</div>`:""}</div></div>`; }).join(""); }

async function loadDashboard() {
  const userId = await getUserId();
  try {
    const res = await fetch(`${BACKEND}/stats?userId=${userId}`);
    if(!res.ok) throw new Error();
    const stats = await res.json();
    renderBehaviorScore(stats.behaviorScore);
    renderRisk(stats.currentRisk);
    renderStats(stats);
    renderPlatforms(stats.aiBreakdown);
    renderCategories(stats.contentCategories);
    renderAchievements(stats.achievements);
    renderActivity(stats.recentEvents);
    setTimeout(()=>renderWeeklyChart(stats.dailyStats),50);
  } catch(err) {
    console.warn("Backend offline, using local storage");
    chrome.storage.local.get(["totalCopies","sessionTime","streak","longestStreak","points","achievements","copyEvents","riskLevel","riskScore"], (data) => {
      const events = data.copyEvents || [];
      const fallback = {
        copyCount: data.totalCopies||0,
        totalTimeMinutes: Math.floor((data.sessionTime||0)/60),
        streak: data.streak||0,
        longestStreak: data.longestStreak||0,
        points: data.points||0,
        currentRisk: { score: data.riskScore||0, level: data.riskLevel||"low", message: "From local cache", emoji:"📦", triggers:[] },
        behaviorScore: { score: Math.max(0,100-(data.riskScore||0)), grade:"—", label:"Cached" },
        achievements: data.achievements||[],
        recentEvents: events.slice(-10).reverse(),
        aiBreakdown: [],
        contentCategories: {},
        dailyStats: []
      };
      renderBehaviorScore(fallback.behaviorScore);
      renderRisk(fallback.currentRisk);
      renderStats(fallback);
      renderPlatforms([]);
      renderCategories({});
      renderAchievements(fallback.achievements);
      renderActivity(fallback.recentEvents);
      const msgEl = document.getElementById("riskMsg");
      if(msgEl) msgEl.textContent = "Backend offline — showing cached data";
    });
  }
}

document.getElementById("refreshBtn")?.addEventListener("click", ()=>{ const btn = document.getElementById("refreshBtn"); if(btn) btn.style.opacity="0.5"; loadDashboard().then(()=>{ if(btn) btn.style.opacity="1"; }); });
loadDashboard();
setInterval(loadDashboard, 10000);
window.addEventListener("resize", ()=>{ if(window.lastDailyStats) renderWeeklyChart(window.lastDailyStats); });