const BACKEND = "https://ai-safety-tool.onrender.com";

async function loadReport() {
  const container = document.getElementById("reportContent");
  if(!container) return;
  
  try {
    const res = await fetch(`${BACKEND}/insights/report?userId=default`);
    if(!res.ok) throw new Error();
    const report = await res.json();
    
    container.innerHTML = `
      <div class="card" style="margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div><div style="font-size:13px;color:var(--text-3)">Period</div><div style="font-size:20px;font-weight:800">${report.period||"Last 7 Days"}</div></div>
          <div><div style="font-size:13px;color:var(--text-3)">Total Copies</div><div style="font-size:28px;font-weight:800">${report.totalCopies||0}</div></div>
          <div><div style="font-size:13px;color:var(--text-3)">Total Time</div><div style="font-size:28px;font-weight:800">${Math.floor((report.totalMinutes||0)/60)}h ${(report.totalMinutes||0)%60}m</div></div>
          <div><div style="font-size:13px;color:var(--text-3)">Avg Risk</div><div style="font-size:28px;font-weight:800;color:${report.avgRisk>50?"#ef4444":report.avgRisk>25?"#f59e0b":"#22c55e"}">${report.avgRisk||0}</div></div>
        </div>
      </div>
      <div class="card"><div class="card-title">Daily Breakdown</div><div style="margin-top:12px">${(report.dailyBreakdown||[]).map(day=>`<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border)"><span>${day.label}</span><span>${day.copies} copies · ${day.timeMinutes} min</span><span style="color:${day.avgRisk>50?"#ef4444":day.avgRisk>25?"#f59e0b":"#22c55e"}">Risk: ${day.avgRisk}</span></div>`).join("")}</div></div>
      <div class="card"><div class="card-title">Summary</div><ul style="margin-top:8px;padding-left:20px"><li>📊 Busiest day: ${report.busiestDay||"—"}</li><li>😴 Quietest day: ${report.quietestDay||"—"}</li><li>📈 Trend: ${report.trend||"steady"}</li><li>⚠️ Flagged copies: ${report.flaggedCopies||0}</li></ul></div>
    `;
  } catch(err) {
    chrome.storage.local.get(["totalCopies","sessionTime","streak"], (data) => {
      container.innerHTML = `
        <div class="card" style="padding:40px;text-align:center">
          <div style="font-size:28px;margin-bottom:12px">📊</div>
          <div>Report from local storage:</div>
          <div style="margin-top:16px">Copies: ${data.totalCopies||0}</div>
          <div>Time: ${Math.floor((data.sessionTime||0)/60)} min</div>
          <div>Streak: ${data.streak||0} days</div>
          <div style="margin-top:20px;font-size:12px">Use AI tools to generate detailed report.</div>
        </div>
      `;
    });
  }
}

document.getElementById("refreshReportBtn")?.addEventListener("click", loadReport);
loadReport();