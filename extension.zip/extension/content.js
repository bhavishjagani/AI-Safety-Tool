/**
 * AI Safety Tool - Content Script v2.0
 * Runs on every page. Detects AI sites, tracks behavior, shows warnings.
 */

const BACKEND = "https://ai-safety-tool.onrender.com";

// ─── Helper: get userId from storage ──────────────────────────────────────────
async function getUserId() {
  return new Promise((resolve) => {
    chrome.storage.local.get("user", (result) => {
      resolve(result.user ? result.user.email : "default");
    });
  });
}

// ─── AI Site Detection ────────────────────────────────────────────────────────
const AI_SITES = {
  "chatgpt.com": "ChatGPT",
  "chat.openai.com": "ChatGPT",
  "claude.ai": "Claude",
  "gemini.google.com": "Gemini",
  "bard.google.com": "Gemini",
  "perplexity.ai": "Perplexity",
  "copilot.microsoft.com": "Copilot",
  "bing.com/chat": "Copilot",
  "poe.com": "Poe",
  "character.ai": "Character.AI",
  "you.com": "You.com",
  "phind.com": "Phind",
  "blackbox.ai": "Blackbox"
};

function detectAISite() {
  const host = location.hostname.toLowerCase();
  const path = location.pathname.toLowerCase();
  for (const [domain, name] of Object.entries(AI_SITES)) {
    if (host.includes(domain) || (host + path).includes(domain)) return name;
  }
  return null;
}

const currentAI = detectAISite();
const isAISite = currentAI !== null;

// ─── State ────────────────────────────────────────────────────────────────────
let copyCount = 0;
let sessionStart = Date.now();
let lastCopyTime = 0;
let rapidCopyCount = 0;
let warningActive = false;
let settings = {
  warningsEnabled: true,
  warningThreshold: 3,
  trackingEnabled: true,
  sensitivityLevel: "medium"
};

chrome.storage.local.get(["settings"], (result) => {
  if (result.settings) settings = { ...settings, ...result.settings };
});

// ─── Text Analysis (lightweight) ──────────────────────────────────────────────
function analyzeText(text) {
  const flags = [];
  if (!text || text.length < 5) return { flags, riskScore: 0 };
  if (text.length > 500) flags.push({ id: "large_content", label: "Large AI content" });
  if (/definitely correct|absolutely certain|100% accurate/i.test(text)) flags.push({ id: "overconfident", label: "Overconfident language" });
  if (/\b(always|never|everyone|nobody)\b/i.test(text)) flags.push({ id: "absolute", label: "Absolute statements" });
  if (text.split(/\s+/).length > 150) flags.push({ id: "heavy_reliance", label: "Heavy reliance (150+ words)" });
  if (/```|function\s*\(|def\s+\w+/i.test(text)) flags.push({ id: "code", label: "Code copied" });
  if (/\b(answer is|therefore|in conclusion|solve)\b/i.test(text) && text.length > 100) flags.push({ id: "homework", label: "Possible homework answer" });
  if (/\b\d{3}[-.]?\d{3}[-.]?\d{4}\b|[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(text)) flags.push({ id: "personal_data", label: "Personal data risk" });
  const riskScore = Math.min(flags.length * 12, 100);
  return { flags, riskScore };
}

function classifyText(text) {
  if (!text) return "general";
  if (/```|function\s*\(|def\s+\w+|import\s+\w+/i.test(text)) return "coding";
  if (/essay|conclusion|introduction|furthermore/i.test(text) && text.length > 300) return "writing";
  if (/calculate|solve|the answer|homework|exercise/i.test(text)) return "homework";
  if (/according to|study shows|research/i.test(text)) return "research";
  if (/story|character|poem|fiction/i.test(text)) return "creative";
  return "general";
}

// ─── Warning Toast System ─────────────────────────────────────────────────────
function createWarningToast(config) {
  const existing = document.getElementById("aisafety-toast");
  if (existing) existing.remove();
  const { title = "AI Safety Alert", message = "", flags = [], type = "warning", duration = 6000 } = config;
  const colors = {
    warning: { bg: "linear-gradient(135deg, #f59e0b, #d97706)", icon: "⚠️" },
    danger: { bg: "linear-gradient(135deg, #ef4444, #dc2626)", icon: "🚨" },
    info: { bg: "linear-gradient(135deg, #3b82f6, #2563eb)", icon: "💡" },
    success: { bg: "linear-gradient(135deg, #22c55e, #16a34a)", icon: "✅" }
  };
  const theme = colors[type] || colors.warning;
  const toast = document.createElement("div");
  toast.id = "aisafety-toast";
  toast.innerHTML = `
    <div style="position:fixed;bottom:24px;right:24px;z-index:2147483647;font-family:system-ui,sans-serif;animation:aisafety-slidein 0.4s cubic-bezier(0.175,0.885,0.32,1.275);max-width:340px;min-width:300px">
      <div style="background:${theme.bg};border-radius:18px;padding:16px 20px;box-shadow:0 20px 60px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.1);backdrop-filter:blur(20px)">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
          <div style="display:flex;align-items:center;gap:8px"><span style="font-size:20px">${theme.icon}</span><span style="color:white;font-weight:700;font-size:14px;letter-spacing:-0.3px">${title}</span></div>
          <button id="aisafety-close" style="background:rgba(255,255,255,0.2);border:none;color:white;width:24px;height:24px;border-radius:50%;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center">×</button>
        </div>
        <p style="color:rgba(255,255,255,0.92);font-size:13px;margin:0 0 10px 0;line-height:1.5">${message}</p>
        ${flags.length ? `<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:8px">${flags.slice(0,3).map(f => `<span style="background:rgba(0,0,0,0.2);color:rgba(255,255,255,0.9);font-size:11px;padding:2px 8px;border-radius:20px">${typeof f === "string" ? f : f.label}</span>`).join("")}</div>` : ""}
        <div style="width:100%;height:3px;background:rgba(255,255,255,0.2);border-radius:2px;margin-top:12px;overflow:hidden"><div id="aisafety-progress" style="height:100%;width:100%;background:rgba(255,255,255,0.7);border-radius:2px;transition:width ${duration}ms linear"></div></div>
      </div>
    </div>
    <style>@keyframes aisafety-slidein{from{transform:translateX(120%);opacity:0}to{transform:translateX(0);opacity:1}}@keyframes aisafety-slideout{from{transform:translateX(0);opacity:1}to{transform:translateX(120%);opacity:0}}</style>
  `;
  document.body.appendChild(toast);
  document.getElementById("aisafety-close")?.addEventListener("click", () => dismissToast(toast));
  setTimeout(() => { const bar = document.getElementById("aisafety-progress"); if (bar) bar.style.width = "0%"; }, 100);
  const timer = setTimeout(() => dismissToast(toast), duration);
  toast._timer = timer;
  warningActive = true;
}

function dismissToast(toast) {
  if (!toast?.firstElementChild) return;
  toast.firstElementChild.style.animation = "aisafety-slideout 0.3s ease forwards";
  setTimeout(() => { toast.remove(); warningActive = false; }, 300);
}

function showMilestoneAlert(copyNum) {
  const milestones = {
    5: { title: "5 Copies — Check In", message: "You've copied AI content 5 times this session. Are you understanding the material?", type: "warning" },
    10: { title: "10 Copies — Take a Break", message: "10 copy events detected. Consider reviewing what you've collected.", type: "danger" },
    20: { title: "High Reliance Detected", message: "20+ copies this session. Your learning may be suffering.", type: "danger" }
  };
  if (milestones[copyNum]) createWarningToast({ ...milestones[copyNum], duration: 8000 });
}

// ─── API Communication ────────────────────────────────────────────────────────
async function sendToBackend(path, data) {
  const userId = await getUserId();
  try {
    await fetch(`${BACKEND}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, ...data })
    });
  } catch (err) {}
}

// ─── Copy Event Handler ───────────────────────────────────────────────────────
function handleCopy(event) {
  if (!settings.trackingEnabled) return;
  const text = window.getSelection()?.toString() || "";
  if (!text || text.length < 5) return;
  const now = Date.now();
  const timeSinceLast = now - lastCopyTime;
  lastCopyTime = now;
  copyCount++;
  if (timeSinceLast < 30000) rapidCopyCount++;
  else rapidCopyCount = 0;
  const analysis = analyzeText(text);
  const category = classifyText(text);
  if (settings.warningsEnabled && analysis.flags.length) {
    let type = "info", title = "AI Content Noted", message = `Tracking your AI copy. ${analysis.flags[0]?.label || ""}`;
    if (analysis.riskScore >= 30) { type = "warning"; title = "Content Risk Detected"; message = `This AI content has ${analysis.flags.length} risk indicator(s).`; }
    if (analysis.riskScore >= 60) { type = "danger"; title = "High-Risk Copy"; message = "This content shows multiple risk signals."; }
    if (rapidCopyCount >= 3) { type = "danger"; title = "Rapid Copying Detected"; message = "You're copying quickly. Slow down and read."; }
    createWarningToast({ title, message, flags: analysis.flags, type, duration: 5000 });
  } else if (settings.warningsEnabled && copyCount % settings.warningThreshold === 0) {
    createWarningToast({ title: `${copyCount} Copies This Session`, message: "Make sure you're learning, not just collecting.", type: "warning", duration: 4000 });
  }
  if ([5, 10, 20, 30].includes(copyCount)) showMilestoneAlert(copyCount);
  sendToBackend("/track/copy", {
    text, ai: currentAI || "Unknown", site: location.hostname,
    flags: analysis.flags, riskScore: analysis.riskScore, category
  });
  chrome.runtime.sendMessage({
    type: "COPY_EVENT",
    data: { copyCount, ai: currentAI, text, flags: analysis.flags, riskScore: analysis.riskScore, category }
  });
}

// ─── Time Tracking ────────────────────────────────────────────────────────────
let timeTrackInterval = null;
let lastTimePing = Date.now();

function startTimeTracking() {
  if (!isAISite) return;
  timeTrackInterval = setInterval(() => {
    if (document.visibilityState === "visible") {
      const elapsed = Math.floor((Date.now() - lastTimePing) / 1000);
      lastTimePing = Date.now();
      sendToBackend("/track/time", { seconds: elapsed, site: location.hostname });
      chrome.runtime.sendMessage({ type: "TIME_UPDATE", data: { elapsed, site: location.hostname, ai: currentAI } });
    }
  }, 10000);
}

// ─── AI Page Enhancements ─────────────────────────────────────────────────────
function injectAIPageBadge() {
  if (!isAISite) return;
  const badge = document.createElement("div");
  badge.id = "aisafety-badge";
  badge.innerHTML = `
    <div style="position:fixed;top:12px;right:12px;z-index:2147483646;background:linear-gradient(135deg,rgba(15,23,42,0.95),rgba(30,41,59,0.95));border:1px solid rgba(56,189,248,0.3);border-radius:20px;padding:6px 12px;display:flex;align-items:center;gap:6px;font-family:system-ui;font-size:12px;color:#94a3b8;cursor:pointer;backdrop-filter:blur(10px)" id="aisafety-badge-inner">
      <span style="width:6px;height:6px;background:#22c55e;border-radius:50%;display:inline-block;animation:aisafety-pulse 2s infinite"></span>
      <span>🛡️ AI Guardian</span>
      <span id="aisafety-badge-count" style="background:rgba(56,189,248,0.15);color:#38bdf8;border-radius:10px;padding:1px 6px;font-weight:600;font-size:11px">0 copies</span>
    </div>
    <style>@keyframes aisafety-pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:0.5;transform:scale(0.8)}}</style>
  `;
  document.body.appendChild(badge);
  document.addEventListener("copy", () => {
    setTimeout(() => {
      const countEl = document.getElementById("aisafety-badge-count");
      if (countEl) {
        countEl.textContent = `${copyCount} cop${copyCount === 1 ? "y" : "ies"}`;
        countEl.style.color = copyCount >= 10 ? "#ef4444" : copyCount >= 5 ? "#f59e0b" : "#38bdf8";
      }
    }, 100);
  });
}

// ─── Init ─────────────────────────────────────────────────────────────────────
function init() {
  if (!settings.trackingEnabled) return;
  document.addEventListener("copy", handleCopy);
  if (isAISite) {
    console.log(`🛡️ AI Safety Tool: Monitoring ${currentAI}`);
    startTimeTracking();
    injectAIPageBadge();
    sendToBackend("/track/session/start", { site: location.hostname, ai: currentAI });
    window.addEventListener("beforeunload", () => {
      sendToBackend("/track/session/end", {});
      if (timeTrackInterval) clearInterval(timeTrackInterval);
    });
    setTimeout(() => {
      createWarningToast({ title: `Monitoring ${currentAI}`, message: "AI Guardian is active. Copy events and usage time will be tracked.", type: "success", duration: 3000 });
    }, 1500);
  }
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
else init();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_STATUS") {
    sendResponse({ isAISite, currentAI, copyCount, sessionTimeSeconds: Math.floor((Date.now() - sessionStart) / 1000) });
  }
  if (msg.type === "UPDATE_SETTINGS") settings = { ...settings, ...msg.settings };
});