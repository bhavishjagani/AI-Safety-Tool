// auth.js - Google Sign-In for Chrome extension
const BACKEND = "https://ai-safety-tool.onrender.com";

let currentUser = null;

export async function signInWithGoogle() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, async (token) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
        return;
      }
      try {
        const userInfo = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
          headers: { Authorization: `Bearer ${token}` }
        }).then(r => r.json());

        const res = await fetch(`${BACKEND}/auth/google`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ idToken: token })
        });
        const data = await res.json();
        if (data.success) {
          currentUser = data.user;
          await chrome.storage.local.set({ user: currentUser });
          resolve(currentUser);
        } else {
          reject(data.error);
        }
      } catch (err) {
        reject(err);
      }
    });
  });
}

export async function signOut() {
  await fetch(`${BACKEND}/auth/logout`, { method: "POST" });
  currentUser = null;
  await chrome.storage.local.remove("user");
  chrome.identity.getAuthToken({}, (token) => {
    if (token) chrome.identity.removeCachedAuthToken({ token });
  });
}

export async function getCurrentUser() {
  if (currentUser) return currentUser;
  const result = await chrome.storage.local.get("user");
  if (result.user) currentUser = result.user;
  return currentUser;
}

export async function getUserId() {
  const user = await getCurrentUser();
  return user ? user.email : "default";
}