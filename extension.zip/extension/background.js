// AI Safety Tool - Background Service Worker v2.0
const BACKEND = "https://ai-safety-tool.onrender.com";

let state = {
  totalCopies: 0,
  sessionTime: 0,
  currentRiskLevel: "low",
  currentRiskScore: 0,
  activeAISite: null,
  aiTabIds: new Set(),
  sessionStart: null
};

function updateBadge() {
  const colors = { low: "#22c55e", moderate: "#f59e0b", high: "#f97316", critical: "#ef4444" };
  chrome.action.setBadgeBackgroundColor({ color: colors[state.currentRiskLevel] || "#22c55e" });
  if (state.totalCopies === 0) {
    chrome.action.setBadgeText({ text: "" });
  } else {
    chrome.action.setBadgeText({ text: state.totalCopies > 99 ? "99+" : String(state.totalCopies) });
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "COPY_EVENT") {
    state.totalCopies = msg.data.copyCount;
    state.activeAISite = msg.data.ai;
    state.currentRiskScore = msg.data.riskScore || 0;
    state.currentRiskLevel = state.currentRiskScore >= 60 ? "high" : state.currentRiskScore >= 30 ? "moderate" : "low";

    const newEvent = {
      timestamp: Date.now(),
      text: msg.data.text || "",
      ai: msg.data.ai,
      flags: msg.data.flags || [],
      riskScore: state.currentRiskScore,
      category: msg.data.category || "general"
    };

    // Store event and counts
    chrome.storage.local.get(["copyEvents", "totalCopies", "sessionTime", "streak", "points", "achievements"], (result) => {
      let events = result.copyEvents || [];
      events.unshift(newEvent);
      if (events.length > 200) events = events.slice(0, 200);
      
      chrome.storage.local.set({
        copyEvents: events,
        totalCopies: state.totalCopies,
        riskLevel: state.currentRiskLevel,
        riskScore: state.currentRiskScore,
        lastActivity: Date.now()
      });
    });
    
    updateBadge();
    sendResponse({ success: true });
    return true;
  }

  if (msg.type === "TIME_UPDATE") {
    state.sessionTime += msg.data.elapsed || 0;
    chrome.storage.local.set({ sessionTime: state.sessionTime });
  }

  if (msg.type === "GET_STATE") {
    sendResponse(state);
    return true;
  }

  if (msg.type === "RESET") {
    state = { totalCopies: 0, sessionTime: 0, currentRiskLevel: "low", currentRiskScore: 0, activeAISite: null, aiTabIds: new Set(), sessionStart: null };
    chrome.storage.local.clear();
    updateBadge();
    sendResponse({ success: true });
  }
});

// Restore on startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(["totalCopies", "riskLevel", "riskScore", "sessionTime"], (data) => {
    state.totalCopies = data.totalCopies || 0;
    state.currentRiskLevel = data.riskLevel || "low";
    state.currentRiskScore = data.riskScore || 0;
    state.sessionTime = data.sessionTime || 0;
    updateBadge();
  });
});

// Daily reset
chrome.alarms.create("dailyReset", { when: new Date().setHours(24,0,0,0), periodInMinutes: 1440 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "dailyReset") {
    chrome.storage.local.remove(["totalCopies", "sessionTime"]);
    state.totalCopies = 0;
    state.sessionTime = 0;
    updateBadge();
  }
});

// Initial load
chrome.storage.local.get(["totalCopies", "riskLevel", "riskScore"], (data) => {
  state.totalCopies = data.totalCopies || 0;
  state.currentRiskLevel = data.riskLevel || "low";
  state.currentRiskScore = data.riskScore || 0;
  updateBadge();
});